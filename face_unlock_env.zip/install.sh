# Shell script to install development environmnet for Face Unlock Use Case

echo "-------------------------------------"
echo "Start installing all the dependencies"
echo "-------------------------------------"

#Install Python 3.6 and virtual environment tool
sudo add-apt-repository ppa:jonathonf/python-3.6
sudo apt-get update
sudo apt-get -y install python3.6
sudo apt-get -y install python3.6-dev
sudo apt-get -y install python3.6-venv
echo "----------------------------------"
echo "Python 3.6 installed successfully!"
echo "----------------------------------"

# Install Dlib dependencies
sudo apt-get -y install build-essential cmake pkg-config
sudo apt-get -y install libx11-dev libatlas-base-dev
sudo apt-get -y install libgtk-3-dev libboost-python-dev
sudo apt-get -y install libssl-dev libffi-dev
echo "-----------------------------------------"
echo "Dlib dependencies installed successfully!"
echo "-----------------------------------------"

# Install bob dependencies
# sudo apt-get -y install libblitz0-dev
# sudo apt-get -y install libhdf5-serial-dev
# sudo apt-get -y install libtiff5-dev
# sudo apt-get -y install libgif-dev
# echo "----------------------------------------"
# echo "bob dependencies installed successfully!"
# echo "----------------------------------------"

# Install OpenCV dependencies
while getopts ":o:" opt; do
	case $opt in
		o)
			if [ "$OPTARG" = "true" ]; then
				echo "---------------------------------------"
				echo "Start installing OpenCV dependencies..."
				echo "---------------------------------------"
				# Remove any previous installations of x264
				sudo apt-get remove x264 libx264-dev

				sudo apt-get -y install build-essential checkinstall cmake pkg-config yasm
				sudo apt-get -y install git gfortran
				sudo apt-get -y install libjpeg8-dev libjasper-dev libpng12-dev
				 
				# If you are using Ubuntu 14.04
				# sudo apt-get install libtiff4-dev
				# If you are using Ubuntu 16.04
				sudo apt-get -y install libtiff5-dev

				sudo apt-get -y install libavcodec-dev libavformat-dev libswscale-dev libdc1394-22-dev
				sudo apt-get -y install libxine2-dev libv4l-dev
				sudo apt-get -y install libgstreamer0.10-dev libgstreamer-plugins-base0.10-dev
				sudo apt-get -y install qt5-default libgtk2.0-dev libtbb-dev
				sudo apt-get -y install libatlas-base-dev
				sudo apt-get -y install libfaac-dev libmp3lame-dev libtheora-dev
				sudo apt-get -y install libvorbis-dev libxvidcore-dev
				sudo apt-get -y install libopencore-amrnb-dev libopencore-amrwb-dev
				sudo apt-get -y install x264 v4l-utils
				echo "-------------------------------------------"
				echo "OpenCV dependencies installed successfully!"
				echo "-------------------------------------------"
      		else
      			echo "OpenCV dependencies will NOT be installed..." >&2
      		fi
      		;;
    	\?)
      		echo "Invalid option: -$OPTARG" >&2
      		;;
        :)
      		echo "Option -$OPTARG requires an argument." >&2
      		exit 1
      		;;
	esac
done
