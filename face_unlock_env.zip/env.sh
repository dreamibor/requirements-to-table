# Script to create the Python virtual dev environment

if [ -d ~/bin ]; then
	echo "Folder ~/bin already exists!"
else
	echo "Folder ~/bin created!"
	mkdir ~/bin/
fi

cd ~/bin/
python3.6 -m venv face
echo "Python virtual environment created successfully."
